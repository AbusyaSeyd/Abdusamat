from django.shortcuts import render
from django.http import HttpResponse, Http404
from .models import *
# from django.template import loader
from django.shortcuts import render, get_object_or_404



def hello_world(request):
  	return render(request,'Online_shop/base.html',{})

def world(request):
	return render(request,'Online_shop/pages/index.html')

def categories(request):
	return render(request,'Online_shop/pages/categories.html')




# Create your views here.
