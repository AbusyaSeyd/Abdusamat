from django.apps import AppConfig


class OnlineShopConfig(AppConfig):
    name = 'Online_shop'
