
from django.urls import path, include

from Online_shop.views import hello_world
from Online_shop.views import world
from Online_shop.views import categories
# from Online_shop.views import  example_view


urlpatterns = [
    
    path('',world),
    path('categories/',categories),
    path('sign/',hello_world),
]
